package com.example.servicetest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("SdCardPath")
public class AlarmActivity extends ListActivity
{
	private static final String fileName = "db.txt";
	private AppData app;
	private EditText et_ee; // 요일
	private EditText et_hh; // 시간
	private EditText et_mm; // 분
	private TextView tv_add;
	private TextView tv_start;
	private ListAdapter mAdapter;  // 리스트
	
	@Override
	public void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_alarm );
		
		
		app = ( AppData )this.getApplicationContext();
		et_ee = ( EditText )findViewById( R.id.et_ee );
		et_hh = ( EditText )findViewById( R.id.et_hh );
		et_mm = ( EditText )findViewById( R.id.et_mm );
		tv_add = ( TextView )findViewById( R.id.text_add );
		tv_start = ( TextView )findViewById( R.id.text_start );

		loadDB();
		
		mAdapter = new ListAdapter( this );
		setListAdapter( mAdapter );
		getListView().setItemsCanFocus( true );
		tv_add.setText( "시간표를 입력하세요." );
		tv_start.setText( "서비스 시작 버튼을 눌러서 시작하세요." );
	}
	
	@Override
	public void onResume()
	{
		super.onResume();
		Intent intent = new Intent( AlarmActivity.this, AlarmService.class );
		stopService( intent );
	}
	
	@Override
	public void onStop()
	{
		Log.d( "1234", "활성화 오류" );
		super.onStop();
	}
	
	@Override
	public void onDestroy()
	{
		Log.d( "1234", "활성화 실패" );
		super.onDestroy();
	}
	
	private void loadDB()
	{
		BufferedReader br = null;
		String line = null;
		try {
			br = new BufferedReader( new FileReader( "/sdcard/" + fileName ) );
			
			try {
				while( ( line = br.readLine() ) != null ) {
					try {
						app.addAlarmTime( app.getDateFormat().parse( line ) );
					} catch ( ParseException pe ) {
						Log.d( "1234", "날짜 포멧 오류" + pe );
					}
				}
			} catch ( IOException ioe ) {
				Log.d( "1234", "에러 발생" + ioe );
			}
			
		} catch( FileNotFoundException fnfe ) {
			Log.d( "1234", "파일 찾기 오류" + fnfe );
			File file = new File( "/sdcard/", fileName );
			try {
				file.createNewFile();
			} catch ( IOException ioe ) {
				Log.d( "1234", "에러 발생" + ioe );
			}
			try {
				br = new BufferedReader( new FileReader( "/sdcard/" + fileName )  );
				try {
					while( ( line = br.readLine() ) != null ) {
						try {
							app.addAlarmTime( app.getDateFormat().parse( line ) );
						} catch ( ParseException pe ) {
							Log.d( "1234", "날짜 포멧 오류" + pe );
						}
					}
				} catch ( IOException ioe ) {
					Log.d( "1234", "에러 발생" + ioe );
				}
				
			} catch (FileNotFoundException  fnfe2) {
				Log.d( "1234", "파일 찾기 오류" + fnfe2 );
			}	
		}
	}
	
	private void saveDB()
	{
		
		BufferedWriter bw = null;
		try {
			File file = new File( "/sdcard/", fileName );
			try {
				file.createNewFile();
			} catch ( IOException ioe ) {
				Log.d( "1234", "에러 발생" + ioe );
			}
			bw = new BufferedWriter( new FileWriter( file ) );
			for( Date date : app.getAlarmList() ) {
				bw.write( app.getDateFormat().format( date ) + "\r\n" );
			} // end for
			bw.close();
		} catch ( IOException ioe ) {
			Log.d( "1234", "에러 발생" + ioe );
		}
	}
	
	
	
	public void onClickAdd( View view ) {
		String ee = et_ee.getText().toString();
		String hh = et_hh.getText().toString();
		String mm = et_mm.getText().toString();
		
		String alarmTime = ee + ' ' + hh + ':' + mm;
		try {
			if( mAdapter.addItem( app.getDateFormat().parse( alarmTime ) ) ) {
				Toast.makeText( this, alarmTime + "추가됨", Toast.LENGTH_SHORT ).show();
			} else {
				Toast.makeText( this, "시간 중복 확인하세요.", Toast.LENGTH_SHORT ).show();
			} // end if then else
			
		} catch (ParseException pe) {
			Toast.makeText( this, "날짜 포멧 에러", Toast.LENGTH_SHORT ).show();
		}
		setListAdapter( mAdapter );
		et_ee.setText( "" );
		et_hh.setText( "" );
		et_mm.setText( "" );
		saveDB();
	}
	
	public void onClickStart( View view ) {
		
		Toast.makeText( this, "서비스 시작", Toast.LENGTH_SHORT ).show();
		Intent intent = new Intent( AlarmActivity.this, AlarmService.class );
		startService( intent );
		saveDB();
		finish();
	}
}