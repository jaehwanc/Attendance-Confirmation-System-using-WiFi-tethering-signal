package com.example.servicetest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Application;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class AppData extends Application
{
	private final SimpleDateFormat sdf = new SimpleDateFormat( "EE HH:mm" );
	                                                    //�� 21:59   : ����� ���� 9�� 59��
	private ArrayList< Date >alarmTimeList = new ArrayList< Date >();
	
	public SimpleDateFormat getDateFormat()
	{
		return sdf;
	}
	
	public boolean addAlarmTime( Date time ) 
	{
		for( Date _time : alarmTimeList ) {
			if( sdf.format( _time ).equals( sdf.format( time ) ) ) {
				Log.d("1234", "시간 중복 확인하세요." );
				return false;
			} // end if
		} // end for
		alarmTimeList.add( time );
		return true;
	}
	
	public final ArrayList< Date >getAlarmList()
	{
		return alarmTimeList;
	}
}