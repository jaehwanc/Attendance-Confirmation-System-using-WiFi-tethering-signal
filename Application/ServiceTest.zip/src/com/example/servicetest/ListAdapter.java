package com.example.servicetest;

import java.util.ArrayList;
import java.util.Date;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

public class ListAdapter extends BaseAdapter
{
	private ArrayList< Date >list_alarm;
	private Context mContext;
	private LayoutInflater mInflater;
	private AppData app;
	
	public ListAdapter( Context context )
	{
		mContext = context;
		app = ( AppData )mContext.getApplicationContext();
		list_alarm = app.getAlarmList();
		mInflater = ( LayoutInflater )mContext.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
	}
	
	public boolean addItem( Date time )
	{
		return app.addAlarmTime( time );
	}
	
	@Override
	public int getCount() {
		return list_alarm.size();
	}

	@Override
	public Object getItem(int arg0) {
		return list_alarm.get( arg0 );
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}
	
	private void remove( int arg0 )
	{
		list_alarm.remove( arg0 );
		this.notifyDataSetChanged();
	}

	@Override
	public View getView( final int arg0, View arg1, ViewGroup arg2 ) {
		View view = null;
		if( view == null ) {
			view = mInflater.inflate( R.layout.row_alarm_list, null );
		} //  end if
		final Date info = ( Date )getItem( arg0 );
		if( info != null ) {
			TextView tv = ( TextView )view.findViewById( R.id.row_time );
			Button btn = ( Button )view.findViewById( R.id.row_delete );
			
			tv.setText( app.getDateFormat().format( info ) );
		    btn.setOnClickListener( new OnClickListener() {
				@Override
				public void onClick( View v )
				{
					remove( arg0 );
				}
		    } );
		} // end if
		return view; 
	}
	
}